#include "filter.h"
#include <math.h>       

FilterOnePole::FilterOnePole(int timerFrequency, float sample[128]){
	sample = sample;
	filtered_low = sample;
	filtered_high = sample;
	idx = 1;
	timerFrequency = timerFrequency;
	timeConstant = 1/(2*pi*timerFrequency);
	tausSamples = timeConstant/128; // timeConstant/sampleSize
	ampfactor = exp(-1/tausSamples);
}

float FilterOnePole::lowFilter(){
	float a0 = 1 - ampfactor;
	float b1 = ampfactor;
	filtered_low[idx] = a0*sample[idx] + b1*filtered_low[idx-1];
	return filtered_low[idx];
}

float FilterOnePole::highFilter(){
	float a0 = (1 + ampfactor)/2;
	float a1 = -(1 + ampfactor)/2;
	float b1 = ampfactor;
	filtered_high[idx] = a0*sample[idx] + a1*sample[idx-1] + b1*filtered_high[idx-1];
	return filtered_high[idx];
}

void FilterOnePole::updateSample(int index, float value){
	sample[index] = value;	
}
