#ifndef FILTER_H            
#define FILTER_H

const float pi = 3.14159265;

// filter struct
struct FilterOnePole
{
	float sample[128];
	float* filtered_low;
	float* filtered_high;
	int idx;
	int timerFrequency; 
	float timeConstant;
	float tausSamples;
	float ampfactor;
	// constructor
	FilterOnePole(int timerFrequency, float sample[128]);
	float lowFilter();
	float highFilter();
	void updateSample(int index, float value);
};


#endif   
